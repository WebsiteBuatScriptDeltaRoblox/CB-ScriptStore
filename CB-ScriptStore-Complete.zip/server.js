const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, "database", "app.db"));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  filename TEXT NOT NULL,
  content TEXT NOT NULL,
  raw_id TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS visits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS heartbeats (
  user_id INTEGER PRIMARY KEY,
  last_seen INTEGER NOT NULL
);
`);

app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-in-production",
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000*60*60*24*30, httpOnly: true, sameSite: "lax" }
}));

const upload = multer({
  dest: path.join(__dirname,"uploads"),
  limits: {fileSize: 1024*1024}
});

function hashPassword(p) {
  return crypto.createHash("sha256").update(p).digest("hex");
}
function auth(req,res,next) {
  if (!req.session.userId) return res.status(401).json({error:"Belum login"});
  next();
}
function makeRawId() {
  return crypto.randomBytes(6).toString("base64url");
}
function safeName(name) {
  return String(name||"untitled").replace(/[^\w.\- ]/g,"_").slice(0,100) || "untitled";
}

app.get("/api/me",(req,res)=>{
  if (!req.session.userId) return res.json({user:null});
  const user=db.prepare("SELECT id,username,email FROM users WHERE id=?").get(req.session.userId);
  res.json({user:user||null});
});

app.post("/api/register",(req,res)=>{
  const {username,email,password}=req.body;
  if(!username||!email||!password) return res.status(400).json({error:"Semua kolom wajib diisi"});
  if(password.length<6) return res.status(400).json({error:"Password minimal 6 karakter"});
  try {
    const info=db.prepare("INSERT INTO users(username,email,password_hash) VALUES(?,?,?)")
      .run(username.trim(),email.trim().toLowerCase(),hashPassword(password));
    req.session.userId=info.lastInsertRowid;
    res.json({ok:true});
  } catch(e) {
    res.status(409).json({error:"Username atau email sudah digunakan"});
  }
});

app.post("/api/login",(req,res)=>{
  const {username,password}=req.body;
  const user=db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if(!user || user.password_hash!==hashPassword(password||""))
    return res.status(401).json({error:"Username atau password salah"});
  req.session.userId=user.id;
  res.json({ok:true});
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.post("/api/heartbeat",auth,(req,res)=>{
  db.prepare("INSERT INTO heartbeats(user_id,last_seen) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET last_seen=excluded.last_seen")
    .run(req.session.userId,Date.now());
  res.json({ok:true});
});

app.get("/api/stats",(req,res)=>{
  db.prepare("INSERT INTO visits DEFAULT VALUES").run();
  const visits=db.prepare("SELECT COUNT(*) n FROM visits").get().n;
  const registered=db.prepare("SELECT COUNT(*) n FROM users").get().n;
  const online=db.prepare("SELECT COUNT(*) n FROM heartbeats WHERE last_seen>?").get(Date.now()-90000).n;
  res.json({visits,registered,online});
});

app.get("/api/files",auth,(req,res)=>{
  res.json(db.prepare("SELECT id,filename,raw_id,created_at,updated_at FROM files WHERE user_id=? ORDER BY id DESC").all(req.session.userId));
});

app.get("/api/files/:id",auth,(req,res)=>{
  const f=db.prepare("SELECT * FROM files WHERE id=? AND user_id=?").get(req.params.id,req.session.userId);
  if(!f) return res.status(404).json({error:"File tidak ditemukan"});
  res.json(f);
});

app.post("/api/files",auth,(req,res)=>{
  const filename=safeName(req.body.filename);
  const content=String(req.body.content||"");
  if(content.length>1024*1024) return res.status(413).json({error:"Script maksimal 1 MB"});
  let raw=makeRawId();
  while(db.prepare("SELECT id FROM files WHERE raw_id=?").get(raw)) raw=makeRawId();
  const info=db.prepare("INSERT INTO files(user_id,filename,content,raw_id) VALUES(?,?,?,?)")
    .run(req.session.userId,filename,content,raw);
  res.json({id:info.lastInsertRowid,raw_id:raw});
});

app.put("/api/files/:id",auth,(req,res)=>{
  const f=db.prepare("SELECT * FROM files WHERE id=? AND user_id=?").get(req.params.id,req.session.userId);
  if(!f) return res.status(404).json({error:"File tidak ditemukan"});
  const filename=safeName(req.body.filename);
  const content=String(req.body.content||"");
  db.prepare("UPDATE files SET filename=?,content=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
    .run(filename,content,f.id);
  res.json({ok:true});
});

app.delete("/api/files/:id",auth,(req,res)=>{
  const r=db.prepare("DELETE FROM files WHERE id=? AND user_id=?").run(req.params.id,req.session.userId);
  res.json({ok:r.changes>0});
});

app.post("/api/upload",auth,upload.single("file"),(req,res)=>{
  if(!req.file) return res.status(400).json({error:"File tidak ada"});
  const content=fs.readFileSync(req.file.path,"utf8");
  fs.unlinkSync(req.file.path);
  let raw=makeRawId();
  while(db.prepare("SELECT id FROM files WHERE raw_id=?").get(raw)) raw=makeRawId();
  const info=db.prepare("INSERT INTO files(user_id,filename,content,raw_id) VALUES(?,?,?,?)")
    .run(req.session.userId,safeName(req.file.originalname),content,raw);
  res.json({id:info.lastInsertRowid,raw_id:raw});
});

app.get("/raw/:rawId",(req,res)=>{
  const f=db.prepare("SELECT content FROM files WHERE raw_id=?").get(req.params.rawId);
  if(!f) return res.status(404).type("text/plain").send("Raw script tidak ditemukan");
  res.type("text/plain; charset=utf-8").send(f.content);
});

app.get("*",(req,res)=>{
  if(req.path.startsWith("/api/")||req.path.startsWith("/raw/")) return res.status(404).send("Not found");
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`CB ScriptStore running at http://localhost:${PORT}`));
