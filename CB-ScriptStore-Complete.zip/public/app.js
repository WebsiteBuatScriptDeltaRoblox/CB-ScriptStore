let currentId=null, preview=false, spaces=2, wrap=true;
const $=id=>document.getElementById(id);
async function api(url,opt={}){const r=await fetch(url,opt);const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||"Terjadi kesalahan");return d}
async function refresh(){const m=await api("/api/me");const acc=$("account");if(m.user){acc.innerHTML=`<span class="user">👤 ${esc(m.user.username)}</span> <button class="ghost" onclick="logout()">Logout</button>`;$("welcome").textContent=`Login sebagai ${m.user.username}`;document.querySelector(".dashboard").style.display="block";loadFiles();heartbeat()}else{acc.innerHTML=`<a href="#login">Login</a> / <a href="#register">Register</a>`;document.querySelector(".dashboard").style.display="none"}}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function loadFiles(){try{const fs=await api("/api/files");$("fileList").innerHTML=fs.map(f=>`<article class="file"><h3>📄 ${esc(f.filename)}</h3><small>Raw: ${esc(f.raw_id)}</small><div class="file-actions"><button onclick="openEdit(${f.id})">✏️ Edit</button><button onclick="copyRaw('${f.raw_id}')">🔗 Copy Raw</button><button onclick="viewRaw('${f.raw_id}')">View</button><button class="ghost" onclick="delFile(${f.id})">🗑️</button></div></article>`).join("");$("empty").style.display=fs.length?"none":"block"}catch(e){}}
async function register(){try{await api("/api/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:$("regUser").value,email:$("regEmail").value,password:$("regPass").value})});location.hash="dashboard";refresh()}catch(e){$("regMsg").textContent=e.message}}
async function login(){try{await api("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:$("loginUser").value,password:$("loginPass").value})});location.hash="dashboard";refresh()}catch(e){$("loginMsg").textContent=e.message}}
async function logout(){await api("/api/logout",{method:"POST"});location.hash="home";refresh()}
function openCreate(){$("modal").style.display="grid"}function closeModal(){$("modal").style.display="none"}
function newFile(){closeModal();currentId=null;preview=false;$("fileName").value="";$("code").value="";updateLines();$("editor").style.display="block";location.hash="editor"}
async function openEdit(id){const f=await api("/api/files/"+id);currentId=id;$("fileName").value=f.filename;$("code").value=f.content;preview=false;togglePreview(true);$("editor").style.display="block";location.hash="editor"}
async function saveEditor(){const body={filename:$("fileName").value,content:$("code").value};try{if(currentId)await api("/api/files/"+currentId,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});else{const d=await api("/api/files",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});currentId=d.id}closeEditor();loadFiles();location.hash="dashboard"}catch(e){alert(e.message)}}
function closeEditor(){$("editor").style.display="none"}
function updateLines(){const n=$("code").value.split("\n").length;$("lines").textContent=Array.from({length:n},(_,i)=>i+1).join("\n")}
$("code").addEventListener("input",updateLines);
$("code").addEventListener("keydown",e=>{if(e.key==="Tab"){e.preventDefault();const s=e.target.selectionStart,e2=e.target.selectionEnd;e.target.value=e.target.value.slice(0,s)+" ".repeat(spaces)+e.target.value.slice(e2);e.target.selectionStart=e.target.selectionEnd=s+spaces;updateLines()}});
function togglePreview(force){preview=force!==undefined?!force:!preview;$("code").style.display=preview?"none":"block";$("preview").style.display=preview?"block":"none";$("preview").textContent=$("code").value}
function toggleSpaces(){spaces=spaces===2?4:2;event.target.textContent="Spaces: "+spaces}
function toggleWrap(){wrap=!wrap;$("code").style.whiteSpace=wrap?"pre-wrap":"pre"}
async function copyRaw(raw){const url=location.origin+"/raw/"+raw;await navigator.clipboard.writeText(url);alert("Raw Link copied:\n"+url)}
function viewRaw(raw){window.open("/raw/"+raw,"_blank")}
async function delFile(id){if(confirm("Hapus project ini?")){await api("/api/files/"+id,{method:"DELETE"});loadFiles()}}
async function uploadFile(){const f=$("uploadFile").files[0];if(!f)return;const fd=new FormData();fd.append("file",f);try{await api("/api/upload",{method:"POST",body:fd});closeModal();loadFiles()}catch(e){alert(e.message)}}
async function stats(){const s=await api("/api/stats");$("visits").textContent=s.visits;$("registered").textContent=s.registered;$("online").textContent=s.online}
async function heartbeat(){try{await api("/api/heartbeat",{method:"POST"})}catch(e){}}
window.addEventListener("hashchange",()=>{const h=location.hash.slice(1);["login","register","editor"].forEach(x=>$(x).style.display=x===h?"grid":"none");if(h==="dashboard"){$("dashboard").style.display="block";loadFiles()}});
setInterval(()=>{stats();heartbeat()},30000);stats();refresh();updateLines();