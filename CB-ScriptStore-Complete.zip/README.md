# CB ScriptStore

Website starter lengkap untuk CB ScriptStore.

## Fitur
- Register + login dengan password hash
- Session login persisten
- Dashboard kosong untuk akun baru
- Create new file
- Upload file (maks 1 MB)
- Code editor + line numbers
- Edit / preview / spaces / no-wrap
- Rename melalui edit filename
- Copy Raw Link
- View raw
- Download raw dari browser
- Delete dengan konfirmasi
- Raw endpoint: `/raw/:rawId`
- Statistik visits, registered, online berbasis database/heartbeat
- Responsive dark cyber UI

## Jalankan
1. Install Node.js 18+.
2. Buka terminal di folder project.
3. Jalankan:
   `npm install`
4. Jalankan:
   `npm start`
5. Buka:
   `http://localhost:3000`

## Production
Ganti `SESSION_SECRET`, gunakan HTTPS, reverse proxy, backup database, rate limiting, dan domain sendiri.
Raw URL akan mengikuti domain yang dipakai, misalnya:
`https://domain-kamu.com/raw/AbCd123`

Catatan: fitur AI voice generator belum terhubung ke provider TTS; UI/marketing copy bisa ditambahkan setelah API TTS dipilih.
